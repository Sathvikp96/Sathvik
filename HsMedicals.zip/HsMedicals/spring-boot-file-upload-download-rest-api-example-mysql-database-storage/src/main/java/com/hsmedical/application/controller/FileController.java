package com.hsmedical.application.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.hsmedical.application.model.Medicine;
import com.hsmedical.application.payload.UploadFileResponse;
import com.hsmedical.application.service.MedicalService;

@RestController
public class FileController {

	private static final Logger logger = LoggerFactory.getLogger(FileController.class);

	@Autowired
	private MedicalService medicalService;

	@PostMapping("/uploadFile")
	public UploadFileResponse uploadFile(@RequestParam("file") MultipartFile file) {
		String fileName = StringUtils.cleanPath(file.getOriginalFilename());
		if (fileName.endsWith(".xlsx") || fileName.endsWith(".xlx")) {
			try {
				excelReader(file);
			} catch (IOException e) {

				e.printStackTrace();
			}
		}
		String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath().path("/downloadFile/")
				.toUriString();

		return new UploadFileResponse(fileName, fileDownloadUri, file.getContentType(), file.getSize());
	}

	@PostMapping("/uploadMultipleFiles")
	public List<UploadFileResponse> uploadMultipleFiles(@RequestParam("files") MultipartFile[] files) {
		return Arrays.asList(files).stream().map(file -> uploadFile(file)).collect(Collectors.toList());
	}

	@GetMapping("/medicine/{name}")
	public Medicine findMedicineByName(@PathVariable String name) {

		Medicine medicine = medicalService.findByMedicineName(name);
		return medicine;
	}

	@GetMapping("/medicineNameLike/{name}")
	public List<Medicine> findMedicineByNameContaining(@PathVariable String name) {

		List<Medicine> medicines = medicalService.findByMedicineNameContaining(name);
		return medicines;
	}

	@GetMapping("/medicines/list")
	public List<Medicine> findAllMedicines() {

		List<Medicine> medicines = medicalService.findAll();
		return medicines;
	}

	@DeleteMapping("/medicineDelete/{name}")
	public void deleteMedicineByName(@PathVariable String name) {

		medicalService.deleteByName(name);

	}

	public void excelReader(MultipartFile reapExcelDataFile) throws IOException {

		List<String> medicines = new ArrayList<String>();
		XSSFWorkbook workbook = new XSSFWorkbook(reapExcelDataFile.getInputStream());
		XSSFSheet worksheet = workbook.getSheetAt(0);
		for (int i = 1; i < worksheet.getPhysicalNumberOfRows(); i++) {
			Medicine medicine = new Medicine();
			XSSFRow row = worksheet.getRow(i);
			int k = 0;
			while (row.getCell(k) != null) {
				medicine.setMedicineName(row.getCell(k++).getStringCellValue().replaceFirst(".", "").trim());
				medicines.add(medicine.getMedicineName());
			}

		}
		medicines = medicines.stream().distinct().collect(Collectors.toList());
		medicalService.saveAll(medicines);

	}

}
