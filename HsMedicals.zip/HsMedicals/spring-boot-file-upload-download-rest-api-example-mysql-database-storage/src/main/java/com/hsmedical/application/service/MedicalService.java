package com.hsmedical.application.service;

import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hsmedical.application.model.Medicine;
import com.hsmedical.application.repository.MedicalRepository;

@Service
public class MedicalService {

	@Autowired
	private MedicalRepository medicalRepository;

	public void saveAll(List<String> medicines) {
		medicines.removeAll(
				findAll().stream().map(medicineName -> medicineName.getMedicineName()).collect(Collectors.toList()));
		List<Medicine> listOfMedicines = new LinkedList<>();
		for (String medicineName : medicines) {
			Medicine medicine = new Medicine();
			medicine.setMedicineName(medicineName);
			listOfMedicines.add(medicine);
		}
		medicalRepository.saveAll(listOfMedicines);
	}

	public List<Medicine> findAll() {
		return medicalRepository.findAll();
	}

	public Medicine findByMedicineName(String name) {

		return medicalRepository.findByMedicineName(name);
	}

	public List<Medicine> findByMedicineNameContaining(String name) {
		return medicalRepository.findByMedicineNameContaining(name);
	}

	public void deleteByName(String name) {
		Medicine medicine = medicalRepository.findByMedicineName(name);
		medicalRepository.deleteById(medicine.getMedicineId());
	}
}
