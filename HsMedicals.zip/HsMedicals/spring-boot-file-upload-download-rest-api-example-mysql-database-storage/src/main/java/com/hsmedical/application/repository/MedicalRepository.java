package com.hsmedical.application.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hsmedical.application.model.Medicine;

@Repository
public interface MedicalRepository extends JpaRepository<Medicine, Integer> {

	public Medicine findByMedicineName(String name);
	public List<Medicine> findByMedicineNameContaining(String name);
}
